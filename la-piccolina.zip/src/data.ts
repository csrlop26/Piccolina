import { PizzaItem, ReviewItem } from './types';

export const PIZZA_MENU: PizzaItem[] = [
  {
    id: 'margherita',
    name: 'Margherita',
    description: 'Tomate San Marzano, mozzarella di bufala, albahaca fresca y AOVE.',
    price: 12.50,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCRukOMQtA4A8lZbxzjLwfOn65m3JScHlQg754ueXqRVNZq6vmdpzBdrBYuUosJSyF9igPJxnBvNUgrC-F-sVJHxoPTvkoAO3-steaW7p34DvSQk-UHsJf4v6ZW0xOqtitJAh1qePeFD73kFwEksCcrJf7yVECycJ-POoZNavo71V1vUjp2VmLSCr9cvhLG0nuSUjRStl0cqsNlCLUG7nTLr9OzWF3jHxm9Sfu5GFvWOU7EIGl7R8rn-dya8UXGkF2hovHs2iTTFBI',
    label: 'VEGGIE',
    defaultIngredients: ['Tomate San Marzano', 'Mozzarella di bufala', 'Albahaca fresca', 'AOVE']
  },
  {
    id: 'pepperoni',
    name: 'Pepperoni',
    description: 'Pepperoni artesanal ahumado, mozzarella, miel picante y orégano.',
    price: 14.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA9XvdMYWTwGq7iGFPJ7RCAh-ySH5tqh6cG4SKCxkJBvoRtfzR49EtP6U0k7Tm-N7NQCKQwlxUC19Wgr-B_pVF5YJorWyi0PWEWCaYTnitzcHsgxuEVnoMO5Z66qQiUD1uoz_RbJTj9CEReFu9EvEvav-lQsTva5WFs96yYiu7PdnOzsDT95N70MD669q92g0cul-0wPT5A1eMz5_Rt5gfZslwdQfMQ3KzyPgaAedocs1DZeu1_jHBHVE7wJPnbiHTsipWwA6gQdKE',
    bestSeller: true,
    defaultIngredients: ['Pepperoni artesanal ahumado', 'Mozzarella', 'Miel picante', 'Orégano']
  },
  {
    id: 'carbonara',
    name: 'Carbonara',
    description: 'Base blanca de pecorino romano, guanciale crujiente y pimienta negra.',
    price: 15.50,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCs6aQ994Twh-1bjysSN9QQST2wJu5S3C6n7IubfIvYj42naP30XUeF1lv0QnJPitR7p1B3h5xSwT25LFR8Prs3IZ9P0ApvoqzPHEmqiv3kxcBc1--XvsHbkthHX1qT343nnT5mTS5Lc_PGrjpNhlzCcmFEXSzSR1QuW-Ya-U_YkspuGvuxDOWcloBh7dmEzFmQXhTqscERfxeMHnwjIi3QWNaeSIRLTjy8jQE1KtlUA6HG-k5VRrd0uKKd246p_3vKlNWciYxcBc8',
    defaultIngredients: ['Base de pecorino romano', 'Guanciale crujiente', 'Yema de huevo', 'Pimienta negra']
  },
  {
    id: 'vegana',
    name: 'Vegana',
    description: 'Pimientos asados, cebolla caramelizada, champiñones y queso vegano.',
    price: 13.50,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB21IgEpqCXWWUaUEclbqt1f3qT-Qf4fqr7Disqn_YkJLc9j7_-up454wpPCcmjKR6d6ZfNwFmFeWxcCJei6f0PsW9dSHQyMDlZLrYHHvMLhsEUZwWgbjD-0karTo58hhQTOvdBJgoBVEHrM3LE_ySMLja9AQzMvjp2YJa1m0UiRczc2wR-wl9z8pAdWOm_WHlrlxtVHMKQyme4yjg5b4Up8MxWxsL64NX-_8oDZ7QjJiGbwdzhRn_rkdD13zEpkztbKUPtIoYGk_A',
    label: 'VEGAN',
    defaultIngredients: ['Pimientos asados', 'Cebolla caramelizada', 'Champiñones', 'Queso vegano artesanal']
  }
];

export const EXTRA_INGREDIENTS = [
  { name: 'Extra Mozzarella di Bufala', price: 1.50 },
  { name: 'Albahaca fresca silvestre', price: 1.00 },
  { name: 'Champiñones Portobello', price: 1.20 },
  { name: 'Pepperoni artesanal extra', price: 1.80 },
  { name: 'Huevo campero orgánico', price: 1.30 },
  { name: 'Aceite de Trufa Negra', price: 1.50 },
  { name: 'Cebolla caramelizada dulce', price: 1.00 },
  { name: 'Miel picante de la casa', price: 1.00 }
];

export const REVIEWS_DATA: ReviewItem[] = [
  {
    id: 'rev-1',
    author: 'MARCO R.',
    text: 'La mejor masa que he probado en años. Una fermentación perfecta con una textura y digestibilidad de auténtica locura.',
    stars: 5,
    bgClass: 'bg-primary',
    textClass: 'text-white',
    rotateClass: '-rotate-6',
    translateClass: 'translate-y-0'
  },
  {
    id: 'rev-2',
    author: 'LAURA G.',
    text: 'El ambiente del local es maravillosamente brutalista y la pizza es pura poesía italiana de vanguardia.',
    stars: 5,
    bgClass: 'bg-secondary-container text-on-secondary-container',
    textClass: 'text-on-secondary-container',
    rotateClass: 'rotate-2',
    translateClass: 'translate-y-4'
  },
  {
    id: 'rev-3',
    author: 'PABLO M.',
    text: 'Si buscas pizza de verdad, crujiente, sabrosa y sin tonterías ni postureos extraños, este es el lugar absoluto.',
    stars: 5,
    bgClass: 'bg-background',
    textClass: 'text-on-surface',
    rotateClass: '-rotate-2',
    translateClass: 'translate-y-8'
  }
];

export const IMAGES_RESOURCES = {
  heroPizza: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCnwN-h-tSIB0QJym2D7cmSG3nLI0ziTiCk8CC0riX8lfDwhO80RSpjrXh_LLa_M_PlmOaaw_XuEX_WqjbGi4atFT9bh9Plv5ib3GzQZIE3zsDG-eooR32WwSos7pEGPmcDihXMuzffJYbJbQgZ3gF2ZdAkMRfwURFbJKYWF_KPdYRufjCXRcytjwGYNcTkAzJeytlStiYRPLDV5N_-XO2iq6h-PXKF25vLzdizh3b_Ft2P8gkNkTiDfNN5gRwR0ymdKNo9fzXloS4',
  storyPepperoni: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA9XvdMYWTwGq7iGFPJ7RCAh-ySH5tqh6cG4SKCxkJBvoRtfzR49EtP6U0k7Tm-N7NQCKQwlxUC19Wgr-B_pVF5YJorWyi0PWEWCaYTnitzcHsgxuEVnoMO5Z66qQiUD1uoz_RbJTj9CEReFu9EvEvav-lQsTva5WFs96yYiu7PdnOzsDT95N70MD669q92g0cul-0wPT5A1eMz5_Rt5gfZslwdQfMQ3KzyPgaAedocs1DZeu1_jHBHVE7wJPnbiHTsipWwA6gQdKE',
  chefCut: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCM8KweoU8iyd8mZtFXCDalactmbY6iYeXN5jkF8UYMoY-a3pqXqStjhYSJwSR7BrOiPjcvQsZ_3GcUmJ1B9M_VjrfhQZ4ejzHFEy76WC2QM8HrA8Q8WmcaceGrnKX63OXIt_K5eawaaBIIYw9-R0SutKBN_NeUscWqovpnxsQVFpYy2AmyTOaFLdZVX9088XgOvqYayWZoQZ3-DKRwBFUk3KEe2bQ0H24-CXQTO1drkT61S0i_QPfI2i7lrPOgnyrSM7RKgSIVT0s'
};
